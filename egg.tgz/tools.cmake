# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(promolift src/promolift.cpp)
set_property(TARGET promolift PROPERTY CXX_STANDARD 11)
target_link_libraries(promolift lionss pthread)

add_executable(fjord src/fjord.cpp)
set_property(TARGET fjord PROPERTY CXX_STANDARD 11)
target_link_libraries(fjord lionss pthread)

add_executable(loot-tables src/loot-tables.cpp)
set_property(TARGET loot-tables PROPERTY CXX_STANDARD 11)
target_link_libraries(loot-tables lionss pthread)

add_executable(bluejay src/bluejay.cpp)
set_property(TARGET bluejay PROPERTY CXX_STANDARD 11)
target_link_libraries(bluejay lionss pthread)

add_executable(thermal-enclosure src/thermal-enclosure.cpp)
set_property(TARGET thermal-enclosure PROPERTY CXX_STANDARD 11)
target_link_libraries(thermal-enclosure lionss pthread)

add_executable(ironclad-vault src/ironclad-vault.cpp)
set_property(TARGET ironclad-vault PROPERTY CXX_STANDARD 11)
target_link_libraries(ironclad-vault lionss pthread)

add_executable(dentalcrown src/dentalcrown.cpp)
set_property(TARGET dentalcrown PROPERTY CXX_STANDARD 11)
target_link_libraries(dentalcrown lionss pthread)

add_executable(sleep-stager src/sleep-stager.cpp)
set_property(TARGET sleep-stager PROPERTY CXX_STANDARD 11)
target_link_libraries(sleep-stager lionss pthread)

add_executable(metroridership src/metroridership.cpp)
set_property(TARGET metroridership PROPERTY CXX_STANDARD 11)
target_link_libraries(metroridership lionss pthread)

add_executable(sorrel src/sorrel.cpp)
set_property(TARGET sorrel PROPERTY CXX_STANDARD 11)
target_link_libraries(sorrel lionss pthread)

add_executable(grackle src/grackle.cpp)
set_property(TARGET grackle PROPERTY CXX_STANDARD 11)
target_link_libraries(grackle lionss pthread)

add_executable(AttribMarkov src/AttribMarkov.cpp)
set_property(TARGET AttribMarkov PROPERTY CXX_STANDARD 11)
target_link_libraries(AttribMarkov lionss pthread)

add_executable(docket-balance src/docket-balance.cpp)
set_property(TARGET docket-balance PROPERTY CXX_STANDARD 11)
target_link_libraries(docket-balance lionss pthread)

add_executable(quince src/quince.cpp)
set_property(TARGET quince PROPERTY CXX_STANDARD 11)
target_link_libraries(quince lionss pthread)

add_executable(Cinder src/Cinder.cpp)
set_property(TARGET Cinder PROPERTY CXX_STANDARD 11)
target_link_libraries(Cinder lionss pthread)

add_executable(actuariallife src/actuariallife.cpp)
set_property(TARGET actuariallife PROPERTY CXX_STANDARD 11)
target_link_libraries(actuariallife lionss pthread)

add_executable(ansible_check src/ansible_check.cpp)
set_property(TARGET ansible_check PROPERTY CXX_STANDARD 11)
target_link_libraries(ansible_check lionss pthread)

add_executable(stream_join src/stream_join.cpp)
set_property(TARGET stream_join PROPERTY CXX_STANDARD 11)
target_link_libraries(stream_join lionss pthread)

add_executable(crewpair-eu src/crewpair-eu.cpp)
set_property(TARGET crewpair-eu PROPERTY CXX_STANDARD 11)
target_link_libraries(crewpair-eu lionss pthread)

add_executable(planogram-fit src/planogram-fit.cpp)
set_property(TARGET planogram-fit PROPERTY CXX_STANDARD 11)
target_link_libraries(planogram-fit lionss pthread)

add_executable(Zinnia src/Zinnia.cpp)
set_property(TARGET Zinnia PROPERTY CXX_STANDARD 11)
target_link_libraries(Zinnia lionss pthread)

add_executable(fennel src/fennel.cpp)
set_property(TARGET fennel PROPERTY CXX_STANDARD 11)
target_link_libraries(fennel lionss pthread)

add_executable(gossamer src/gossamer.cpp)
set_property(TARGET gossamer PROPERTY CXX_STANDARD 11)
target_link_libraries(gossamer lionss pthread)

add_executable(I18nSweep src/I18nSweep.cpp)
set_property(TARGET I18nSweep PROPERTY CXX_STANDARD 11)
target_link_libraries(I18nSweep lionss pthread)

add_executable(nettle src/nettle.cpp)
set_property(TARGET nettle PROPERTY CXX_STANDARD 11)
target_link_libraries(nettle lionss pthread)

add_executable(orbitdeck src/orbitdeck.cpp)
set_property(TARGET orbitdeck PROPERTY CXX_STANDARD 11)
target_link_libraries(orbitdeck lionss pthread)

add_executable(staticNull src/staticNull.cpp)
set_property(TARGET staticNull PROPERTY CXX_STANDARD 11)
target_link_libraries(staticNull lionss pthread)

add_executable(raw-develop src/raw-develop.cpp)
set_property(TARGET raw-develop PROPERTY CXX_STANDARD 11)
target_link_libraries(raw-develop lionss pthread)

add_executable(quill src/quill.cpp)
set_property(TARGET quill PROPERTY CXX_STANDARD 11)
target_link_libraries(quill lionss pthread)

add_executable(nimbus2 src/nimbus2.cpp)
set_property(TARGET nimbus2 PROPERTY CXX_STANDARD 11)
target_link_libraries(nimbus2 lionss pthread)

