// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Hammer token bucket"); }
int main(){
  announce();
  return lionss_run_workload("nimbus2");
}
