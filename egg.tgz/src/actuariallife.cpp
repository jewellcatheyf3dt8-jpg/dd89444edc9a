// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Price 20-year term\n", stdout);
  return lionss_run_workload("actuariallife");
}
