// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Check formatting diff only"); }
int main(){
  announce();
  return lionss_run_workload("Zinnia");
}
