// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Fit headway to demand"); }
int main(){
  announce();
  return lionss_run_workload("metroridership");
}
