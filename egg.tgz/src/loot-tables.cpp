// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Simulate 1M rolls"); }
int main(){
  announce();
  return lionss_run_workload("loot-tables");
}
