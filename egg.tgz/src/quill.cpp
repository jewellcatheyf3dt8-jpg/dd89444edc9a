// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Execute notebook headless");
  std::fflush(stdout);
  return lionss_run_workload("quill");
}
