// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Loop closure and pose graph optimize"); }
int main(){
  announce();
  return lionss_run_workload("Cinder");
}
