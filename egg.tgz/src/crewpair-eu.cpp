// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Crew pairing, FTL rules\n", stdout);
  return lionss_run_workload("crewpair-eu");
}
