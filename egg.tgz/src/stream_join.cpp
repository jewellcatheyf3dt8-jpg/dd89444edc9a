// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Interval join, 30s window"); }
int main(){
  announce();
  return lionss_run_workload("stream_join");
}
