// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Markov removal-effect attribution"); }
int main(){
  announce();
  return lionss_run_workload("AttribMarkov");
}
