// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Rotate wrapped keys"); }
int main(){
  announce();
  return lionss_run_workload("ironclad-vault");
}
