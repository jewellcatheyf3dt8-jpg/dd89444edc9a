// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Generate crown proposal\n", stdout);
  return lionss_run_workload("dentalcrown");
}
