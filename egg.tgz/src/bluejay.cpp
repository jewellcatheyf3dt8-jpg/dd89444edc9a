// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Lattice-Boltzmann channel flow\n", stdout);
  return lionss_run_workload("bluejay");
}
