// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Assign to 6 judges by load\n", stdout);
  return lionss_run_workload("docket-balance");
}
