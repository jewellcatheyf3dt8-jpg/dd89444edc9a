// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("STA/LTA phase picking\n", stdout);
  return lionss_run_workload("fennel");
}
